#ifndef VERSION_H_
#define VERSION_H_

#define VERSION "0.6.2"

#endif  // VERSION_H_
